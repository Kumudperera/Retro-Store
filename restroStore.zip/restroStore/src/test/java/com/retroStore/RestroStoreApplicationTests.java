package com.retroStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestroStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
