package com.retroStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestroStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestroStoreApplication.class, args);
	}

}
